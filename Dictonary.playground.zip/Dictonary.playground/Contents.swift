//создание Dictionary<Key, Value>
var namesOfInteger = [Int: String]()
namesOfInteger.reserveCapacity(3) //для динамического словаря создали зарезервированное место
var airports: [String: String] = ["YYZ": "Toronto pearson", "DUB": "Dublin"]
airports.reserveCapacity(5) //тк мы будем добавлять элементы
let train = ["YYZ": "Toronto pearson", "DUB": "Dublin"]
//доступ и изменение
print("The airports dictionary contains \(airports.count) items") //узнаем длинну
namesOfInteger[4] = "four" //добавили связку
if airports.isEmpty { //проверка на непустой
    print("The airports dictionary is empty.")
} else {
    print("The airports dictionary is not empty.")
}
airports["LNR"] = "London"
airports["LNR"] = "London Heathrom"
print(airports.updateValue("Samara", forKey: "YYZ") as Any) //updateValue - возвращает сторое значение заменяя текущее на новое
print(airports["YYZ"] as Any)
if let oldValue = airports.updateValue("Dublin Airports", forKey: "DUB") {
    print("The old value for DUB was \(oldValue)")
}
airports["APL"] = "Apple internation"
airports["APL"] = nil //удаление информации из ячейки
print(namesOfInteger)
namesOfInteger = [:] //очистили словарь
if let removedValue = airports.removeValue(forKey: "DUB") { //удаление пары ключ - значение
    print("The removed airport's name is \(removedValue).")
} else {
    print("The airports dictionary dies not contain a value for DUB")
}
//итерация по словарю
for (airportCode, airportName) in airports { //итерация по ключ-значение
    print("\(airportCode): \(airportName)")
}
print(airports.sorted(by: <)) //сортировка
for airportName in airports.values { //итерация по значению
    print("Airport code: \(airportName)")
}
for airportCode in airports.keys {   //итерация по ключу
    print("Airoport keys: \(airportCode)")
}
let airportCodes = [String](airports.keys) //извлечение ключей в массив строк
let airportName = [String](airports.values) //извлечение значений в имассив строк
print(airportName, airportCodes, separator: ", ")
