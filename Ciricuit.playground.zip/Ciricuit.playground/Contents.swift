import Foundation
//метод Sorted
func backWard(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}
var names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]
print(names.sorted(by: backWard))
var reversedName = names.sorted(by: { (s1: String, s2: String) -> Bool in
    return s1 > s2
})
reversedName = names.sorted(by: { s1, s2 in return s1 > s2 })
reversedName = names.sorted(by: { s1, s2 in s1 > s2})
reversedName = names.sorted(by: { $0 > $1})
reversedName = names.sorted(by: >)
print(reversedName)
//последующие замыкания
reversedName = names.sorted() { $0 > $1 }
reversedName = names.sorted { $0 > $1 }
func someFunctionThatTakesAClosure(closure: () -> Void) {
}
someFunctionThatTakesAClosure(closure: {
})
someFunctionThatTakesAClosure() {
}
let digitNames = [
    0: "Zero", 1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
]
let numbers = [16, 58 , 510]
let strings = numbers.map { (number) -> String in
    var number = number
    var output = ""
    repeat {
        output = digitNames[number % 10]! + output
        number /= 10
    } while number > 0
    return output
}
print(strings)
//захват значений
func makeIncrementer(forIncrement amout: Int) -> () -> Int {
    var runningTotal = 0
    func incrementer() -> Int {
        runningTotal += amout
        return runningTotal
    }
    return incrementer
}
let incrementByTen = makeIncrementer(forIncrement: 10)
print(incrementByTen())
let incrementBySeven = makeIncrementer(forIncrement: 7)
incrementBySeven()
let alsoIncrementByten = incrementByTen
alsoIncrementByten()
print(incrementByTen(), alsoIncrementByten())
//сбегающее замыкание
//@escaping - показать что замыкание может сбегать
var completionHandlers: [() -> Void] = []
func someFunctionWith(completionhandler: @escaping () -> Void) {
    completionHandlers.append{completionHandlers}
}
func someFunctionWithNonescapingClosure(closure: () -> Void) {
    closure()
}
class SomeClass {
    var x = 10
    func doSomething() {
        someFunctionThatTakesAClosure { self.x = 100 }
        someFunctionThatTakesAClosure { x = 200 }
    }
}

let instance = SomeClass()
instance.doSomething()
print(instance.x)
completionHandlers.first?()
print(instance.x)

func performOperation(_ op1: Double, _ op2: Double, _ operation: (Double, Double) -> Double) -> Double {
    return operation(op1, op2)
}
let result = performOperation(1.0, 2.0, {(op1, op2) -> Double in op1 + op2})
//автозамыкания
print(names.count)
let customerProvider = { names.remove(at: 0) } //замыкание, удаление после непосредственного вызова
print(names.count)
print("Now serving \(customerProvider())!")
print(names)
func serve(customer customerProvider: () -> String) {
    print("Now serving \(customerProvider())!")
}
serve(customer: {names.remove(at: 0)})
func serves(customer customerProvider: @autoclosure () -> String) {
    print("Now serving \(customerProvider())!")
}
serves(customer: names.remove(at: 0))
