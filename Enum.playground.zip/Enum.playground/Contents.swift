//синтаксис
enum CompassPoint {
    //здесь объявленны перечисления
    case north
    case south
    case east
    case west
}
enum Planet {
    case mercury, venus, earth, mars
}
enum Barcode {
    case ups(Int, Int, Int, Int)
    case qrCode(String)
}
//обращение
var directionToHead = CompassPoint.west
directionToHead = .east
var productBarcode = Barcode.ups(8, 85909, 51226, 3)
productBarcode = Barcode.qrCode("ABCDEFGHIJKLMNOP")
//использование перечислений с инструкцией switch
switch directionToHead {
case .north:
    print("Lots of planets have a north")
case .south:
    print("Watch out for penguins")
case .east:
    print("Where the sun rises")
default:
    print("Not a safe place for humens")
}
switch productBarcode {
case .ups(let numberSystem, let manufacturer, let product, let check):
    print("UPC: \(numberSystem), \(manufacturer), \(product), \(check).")
case let .qrCode(productCode): //если все как константы для краткости можно 1 раз let
    print("QR code: \(productCode)")
}
//итерация по кейсам перечисления
enum Beverage: CaseIterable {
    case coffee, tea, juice
}
let numberOfChoices = Beverage.allCases.count
print("\(numberOfChoices) beverages available")
for beverage in Beverage.allCases {
    print(beverage)
}
