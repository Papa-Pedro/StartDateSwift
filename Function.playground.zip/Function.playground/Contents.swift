//объявление и вызов
func greet(person: String) -> String {
    return "Hello, " + person + "!"
}
//функция без параметра
func sayHellowWorld() -> String {
    return "Hellow, world"
}
//функция с несколькими параметрами
func greet(person: String, alredyGreeted: Bool) -> String { //можно использовать одинаковые имена разные параметры (аналог перегрузки)
    if alredyGreeted {
        return greet(person: person)
    } else {
        return sayHellowWorld()
    }
}
//функция не возворащающая значение
func greeting(person: String) {
    print("Hello, \(person)")
}
func printAndCount(string: String) -> Int {
    print(string)
    return string.count
}
func printWithoutCouting(string: String) {
    let _ = printAndCount(string: string)
}
//функция возвращающая несколько значений
func minMax(array: [Int]) -> (min: Int, max: Int) {
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value > currentMax {
            currentMax = value
        } else if value < currentMin {
            currentMin = value
        }
    }
    return (currentMin, currentMax)
}
//опциональный кортеж
func minMaxOptional(array: [Int]) -> (min: Int, max: Int)? {
    if array.isEmpty { return nil }
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value > currentMax {
            currentMax = value
        } else if value < currentMin {
            currentMin = value
        }
    }
    return (currentMin, currentMax)
}
//ярлыки аргументов и имена параметров функции
func someFunction(firstParameterName: Int, secondParameterName: Int) {
    //внутири тела функции first.. and second.. ссылаются на значения аргументов,  первого и второго параметров
}
someFunction(firstParameterName: 1, secondParameterName: 2)
//пропуск ярлыка аргумента
func someFunctionWithoutLabel(_ firstParameterName: Int, secondParameterName: Int) { }
someFunctionWithoutLabel(1, secondParameterName: 2)
//значения по умолчанию
func someFunctionWithPrimary(firstParameterName: Int, secondParameterName: Int = 12) {}
someFunctionWithPrimary(firstParameterName: 3) //secondParameterName = 12
someFunctionWithPrimary(firstParameterName: 3, secondParameterName: 6) //secondParameterName = 6
//вариативные параметры - параметр может иметь сразу несколько значений
func arithmeticMean(_ numbers: Double...) -> Double {
    var total: Double = 0
    for number in numbers {
        total += number
    }
    return total / Double(numbers.count)
}
//сквозные параметры
func swapTwoInts(_ a: inout Int, _ b: inout Int) {
    let temporaryA = a
    a = b
    b = temporaryA
}
var someInt = 3
var anotherInt = 107
swapTwoInts(&someInt, &anotherInt)
print("someInt is now \(someInt), and anotherInt is now \(anotherInt)")
arithmeticMean(1, 2, 3, 4, 5)
arithmeticMean(3, 8.25, 18.75)
//функциональный тип - тип состоящий их типов параметров и типа возвращаемого значения
func addTwoInts(a: Int, _ b: Int) -> Int {
    return a + b
} //тип (Int, Int) -> Int - функциональный тип
func multiplyTwoInts(a: Int, _ b: Int) -> Int {
    return a * b
}
//использование функциональных типов
let anotherMathFunction = addTwoInts
var mathFunction: (Int, Int) -> Int = addTwoInts
print("Result: \(mathFunction(2, 3))")
mathFunction = multiplyTwoInts
print("Result: \(mathFunction(2, 3))")
//функциональные типы как типы аргументов
func printMathResult(_ mathFunction: (Int, Int) -> Int, _ a: Int, _ b: Int) {
    print("Result: \(mathFunction(2, 3))")
}
printMathResult(addTwoInts, 3, 5)
//функциональные типы как возвращаемые типы
func stepForward(_ input: Int) -> Int {
    return input + 1
}
func stepBackward(_ input: Int) -> Int {
    return input - 1
}
func chooseStepFunction(backward: Bool) -> (Int) -> Int {
    return backward ? stepBackward : stepForward
}
var currentValue = 3
let moveNearerToZero = chooseStepFunction(backward: currentValue > 0)
while currentValue != 0 {
    print("\(currentValue)...")
    currentValue = moveNearerToZero(currentValue)
}
//вложенные функции
func choseStepFunction(backward: Bool) -> (Int) -> Int {
    func stepForward1(input: Int) -> Int { return input + 1}
    func stepBackward1(input: Int) -> Int { return input - 1}
    return backward ? stepBackward1 : stepForward1
}
currentValue = -4
let moveNearerToZero1 = chooseStepFunction(backward: currentValue > 0)
while currentValue != 0 {
    print("\(currentValue)...")
    currentValue = moveNearerToZero1(currentValue)
}
print(greet(person: "Diana"))
print(sayHellowWorld())
print(greet(person: "Tim", alredyGreeted: true))
greeting(person: "Dave")
print(printAndCount(string: "hay World"))
let bound = minMax(array: [8, -6, 2, 109, 3, 71])
print("Min is \(bound.min) and max is \(bound.max)")
var array: [Int] = []
if let bounds = minMaxOptional(array: array) {
    print("Min is \(bounds.min) and max is \(bounds.max)")
} else { print("Array is empty") }
