//создание множества var(set) ... Set<Elemet>
var letters = Set<Character>()
var favoriteGenres: Set<String> = ["Rock","Classical","Hip hop"]
var oddDigits: Set = [1,2,5,7,9]
//изменение множества
print("letters make \(letters.count) elements") //колличество элементов .count
letters.insert("a") //добавление элемента
print(letters)
if favoriteGenres.isEmpty { //проверка на непустое множество
    print("I'm a lover")
} else {
    print("I have a preference")
}
if let removedGenre = favoriteGenres.remove("Rock") { //удаление значения элемента из множества
    print("I'm tired \(removedGenre)")
} else {
    print("Not interest") //removedGenre виден только в if но не в else
}
if favoriteGenres.contains("Funk") {
    print("Yes, i'm do")
} else {
    print("Much more...")
}
letters = [] //переприсвоение пустому множеству
print(letters)
//итерация по множеству
for genre in favoriteGenres { //пробежка по элементам
    print("\(genre)")
}
for genre in favoriteGenres.sorted() { //сортировка по алфавиту
    print("\(genre)")
}
favoriteGenres.removeAll() //обнуление множества
//операции с множествами
//базовые операции
let evenDigits: Set = [0,2,4,6,8]
print(oddDigits)
print(evenDigits)
print(oddDigits.union(evenDigits).sorted()) //объединение множеств
print(oddDigits.intersection(evenDigits).sorted()) //пересечение
print(oddDigits.subtracting(evenDigits).sorted()) //oddDigits без эелементов evenDigits
print(oddDigits.symmetricDifference(evenDigits).sorted()) //исключающее объединение
//взаимосвязь и равенства
let secondDigits: Set = [4,6]
if evenDigits == secondDigits { //проверка на равенство
    print("evenDigits equally secondDigits")
} else {
    print("evenDigits not equally secondDigits")
}
print(secondDigits.isSubset(of: evenDigits)) //проверка на включение в множество evenDigits
print(evenDigits.isSuperset(of: secondDigits)) //содержит ли множество evenDigits все значения secondDigits
print(evenDigits.isStrictSubset(of: secondDigits)) //являетсяя ли множество evenDigits подмножеством secondDigits
print(evenDigits.isStrictSuperset(of: secondDigits)) //являетсяя ли множество evenDigits надмножеством secondDigits
print(evenDigits.isDisjoint(with: oddDigits)) //отсутствуют ли общие значения
