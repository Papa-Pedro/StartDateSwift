//инициализация
let arrayInt = [1,2,3,4,5]
var arrayStudent = ["Ben","Tim","Clop"]
var emptyStudent: [String] = []
var emptyFloat: Array<Float> = Array()
var digitCouts = Array(repeating: 0, count: 10)
//создание массива сумированием двых ранее созданых
var sixInd = arrayInt + digitCouts
//резервирование памяти для массива
var knownSize: [Int] = [];
knownSize.reserveCapacity(20) //создали место для 20 элементов, для того что бы не было перераспределение памяти
print(arrayStudent)
//перебор по элементам в массиве
for element in arrayInt {
    print("I have \(element) apple")
}
for (index, value) in arrayStudent.enumerated() { //перебор и по значениям и по номерам
    print("\(index+1): \(value)")
}
//проверка на непустой/количество элементов
if arrayInt.isEmpty {  //если проверять на пустоту с помощью .cout то опциональность понизится
    print("Array is empty")
} else {
    print("Array have \(arrayInt.count) elements") //.cout сколько эл в массиве
}
if emptyFloat.isEmpty {
    print("Array (EmptyFloat) is empty")
} else {
    print("array have \(emptyFloat.count) elemens")
}
//доступ к первому(first) и последнему(last) элементу
if let firstElement = arrayInt.first, let lastElement = arrayInt.last { //if проверка на пустоту, eсли пустой вывода не будет!!
    print(firstElement, lastElement, separator: ", ")
} else {
    print("Array is empty")
}
print(arrayInt.first, arrayInt.last, separator: ", ") //чем отличается выход Optional(1) и 1, почему появляется эта надпись??
print(emptyFloat.first, emptyFloat.last, separator: ", ")
//обращение к элемента
print(arrayInt[1], arrayInt[3], separator: ", ") //print(arrayInt(5), emptyFloat(1)) вызовет ошибку, пытаемся обратиться к несуществующему элементу!!
//добавление/удаление элкментов
//метод append("contentsOf"_:) добавление элемента в конец
emptyStudent.append("Maxime")
emptyStudent += ["Alex"]
emptyStudent.append(contentsOf: ["Shakia","William"])
emptyStudent.append(contentsOf: arrayStudent)
print(emptyStudent)
//вставка в n позицию(метод insert((contntensOf)_: at:)
emptyStudent.insert("Liam", at: 4)
emptyStudent.insert(contentsOf: ["Mark","Tom"], at: 3)
emptyStudent.insert(contentsOf: arrayStudent, at: 5)
print(emptyStudent)
//удаление элементов(метод remove((substring)_at:) и removeLast(), removeFirst и removeAll)
emptyStudent.removeLast()
emptyStudent.remove(at: 5)
print(emptyStudent)
//замена эелемента
if let i = emptyStudent.firstIndex(of: "William") {
    emptyStudent[i] = "Will"
}
print(emptyStudent)
//очистка массива
emptyStudent.removeAll()
//массив из ссылок на объект класса, изменение во всех массивах или нет
class IntegerReference {
    var value = 0 //значения по умолчанию
}
var firstInteger = [IntegerReference(),IntegerReference()]
var secondIndeger = firstInteger

firstInteger[0].value = 100
print(secondIndeger[0].value, firstInteger[0].value, separator: ", ")
firstInteger[0] = IntegerReference() //обнуление значения 0-го элемента, cоздали новую ссылку
print(secondIndeger[0].value, firstInteger[0].value, separator: ", ")
/*при копировании массивы будут использовать 1 и тоже хранилище, до тех пор пока 1 из элементов массива(любого)
не изменится, тогда создается новое хранилища только для измененого массива */




