//определение протокола
protocol SomeProtocol {
    //определение протокола
}
protocol FirstProtocol {
    //определение протокола
}
//struct
