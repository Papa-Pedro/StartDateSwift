//объявление опционала
var my_variable: Int?
var my_variable1: Optional<Int>
//опционал с nil значением
var my_var: Int? = nil
var myVar: Optional<Int> = Optional.none
var myVar1 = Optional<Int>.none
var myV = Optional(42) //тип. some-значения Int определен неявно
var myV1 = Optional<Int>(42) // явное указание типа Int для наглядности
var myV2 = Int?(42) // тип Int необходимо указать явно
var myV3: Int? = 42 // тип Int необходимо указать явно
var myV4 = Optional.some(42) // тип Int опеределен неявно
var myV5 = Optional<Int>.some(42) // явное указание типа для наглядности
//myV = myV1 + myV2
//print(myV)
