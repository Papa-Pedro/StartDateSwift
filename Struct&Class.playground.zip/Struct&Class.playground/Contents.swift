//синтаксис
struct Resolution {
    //здесь пишется определение структуры
    var width = 0
    var height = 0
}
class VideoMode {
    //здесь пишется определение класса
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}
//экземпляры(объявление, что бы работать с ними)
let someResolution = Resolution() //инициализация структуры
let someVideoMode = VideoMode() //класса
let hd = Resolution(width: 1920, height: 1080) //cтруктура с начальными значениями
//доступ
someVideoMode.resolution.width = 1280
print("The width of someResolution is \(someResolution.width)")
print("The width of someVideo is \(someVideoMode.resolution.width)")
var cinema = hd //cоздается новый экземляр(новая память)
cinema.width = 2048
print("cinema is now \(cinema.width) pixels wide")
print("hd is still \(hd.width) pixels wide")
//пример перечисления
enum CompassPoint {
    case north, south, east, west
    mutating func turnNorth() {
        self = .north
    }
}
var currentDirection = CompassPoint.west
let rememberedDirection = currentDirection
currentDirection.turnNorth()

print("Текущее направление - \(currentDirection)") //пошел читать перечисления... вернусь позже 
