func swapTwoElement<T>( a: inout T, b: inout T) {
    let element = a
    a = b
    b = element
}
var firstElement = "One"
var secondElement = "Two"
swapTwoElement(a: &firstElement, b: &secondElement)
firstElement
secondElement

struct Stack<T> {
    var items = [T]()
    init(){}
    init(_ elements: T...){
        self.items = elements
    }
    mutating func push(_ item: T) {
        items.append(item)
    }
    mutating func pop() -> T {
        return items.removeLast()
    }
}

/*var stackOfString = Stack<String>()
stackOfString.push("uno")
stackOfString.push("dos")
print(stackOfString)*/
var stackOfInt = Stack(1, 2, 3, 4, 5)
var stackOfString = Stack<String>()
//let fromTheTop = stackOfString.pop()
stackOfString.push("uno")
stackOfString.push("dos")
print(stackOfString)
